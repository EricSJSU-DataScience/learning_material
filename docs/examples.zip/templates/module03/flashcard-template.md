---
layout: default
title: Flashcard Template
parent: Module 03
grand_parent: Templates
nav_order: 3
---

# Topic Flashcards

Click a card to reveal the answer. Use Shuffle to randomize.

{% include flashcard.html %}

<div id="CHANGE-THIS-ID"></div>

<script>
renderCards("CHANGE-THIS-ID", [
  { front: "Question or term on the front", back: "Answer or definition on the back" },
  { front: "What does <code>len()</code> do?", back: "Returns the number of items.<br><code>len('hello') → 5</code>" },
  { front: "Third card question", back: "Third card answer" }
]);
</script>
