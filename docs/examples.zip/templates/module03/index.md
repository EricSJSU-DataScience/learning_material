---
layout: default
title: Module 03
parent: Templates
nav_order: 3
has_children: true
---

# Module 03: Basic Templates

| Template | Use for |
|----------|---------|
| [Notes](notes-template.md) | Reference notes and summaries |
| [Quiz](quiz-template.md) | Multiple choice questions |
| [Flashcards](flashcard-template.md) | Flip-card review |
