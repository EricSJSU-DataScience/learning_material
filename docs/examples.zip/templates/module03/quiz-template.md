---
layout: default
title: Quiz Template
parent: Module 03
grand_parent: Templates
nav_order: 2
---

# Topic Quiz

{% include mcq.html %}

<div id="CHANGE-THIS-ID"></div>

<script>
renderQuiz("CHANGE-THIS-ID", [
  {
    q: "Question text here?",
    options: ["Option A", "Option B", "Option C", "Option D"],
    answer: 0,
    explanation: "Explanation of why Option A is correct."
  },
  {
    q: "Second question?",
    options: ["Option A", "Option B", "Option C", "Option D"],
    answer: 2,
    explanation: "Explanation of why Option C is correct."
  }
]);
</script>
