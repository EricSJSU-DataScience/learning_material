---
layout: default
title: Templates
nav_order: 99
has_children: true
---

# Templates

Copy files from these modules when adding new content.

| Module | Description |
|--------|-------------|
| [Module 01](module01/) | Basic templates — notes, quiz, flashcards |
| [Module 02](module02/) | Placeholder for future template types |
