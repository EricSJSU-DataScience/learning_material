---
layout: default
title: Module 01
parent: Templates
nav_order: 1
has_children: true
---

# Module 01: Basic Templates

| Template | Use for |
|----------|---------|
| [Notes](notes-template.md) | Reference notes and summaries |
| [Quiz](quiz-template.md) | Multiple choice questions |
| [Flashcards](flashcard-template.md) | Flip-card review |
