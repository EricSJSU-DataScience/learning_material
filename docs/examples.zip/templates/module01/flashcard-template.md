---
layout: default
title: Flashcard Template
parent: Module 01
grand_parent: Templates
nav_order: 3
---

# Topic Flashcards

Click a card to reveal the answer. Use Shuffle to randomize.

{% include flashcard.html %}

<div id="CHANGE-THIS-ID"></div>

<script>
renderCards("CHANGE-THIS-ID", [
  {
    front: "Question or term on the front",
    back: "Answer or definition on the back"
  },
  {
    front: "What does <code>len()</code> do?",
    back: "Returns the number of items.<br><code>len('hello') → 5</code>"
  },
  {
    front: "Third card question",
    back: "Third card answer"
  }
]);
</script>

<!--
HOW TO USE:
1. Copy this file to your topic folder, e.g. docs/sql/flashcards.md
2. Change front matter: title, parent, grand_parent (if 3rd level)
3. Change "CHANGE-THIS-ID" to something unique, e.g. "sql-cards"
4. Fill in your front/back pairs
5. You can use <code> and <br> inside strings for formatting
-->
