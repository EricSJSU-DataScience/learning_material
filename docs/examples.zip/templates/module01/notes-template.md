---
layout: default
title: Notes Template
parent: Module 01
grand_parent: Templates
nav_order: 1
---

# Topic Title

Brief one-line description of what this page covers.

---

## Concept

Explain the concept in plain English.

## Syntax

```python
# Show the basic syntax here
example = "value"
```

## Examples

### Example 1: Basic usage

```python
x = 10
print(x)  # 10
```

### Example 2: Common pattern

```python
numbers = [1, 2, 3]
for n in numbers:
    print(n)
```

## Key Points

- First important thing to remember
- Second important thing
- Edge case or common mistake

## Reference

| Term | Meaning |
|------|---------|
| variable | A named container for a value |
| function | A reusable block of code |

---

**Next:** [Link to next page](next-page.md)
