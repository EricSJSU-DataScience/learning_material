---
layout: default
title: Quiz Template
parent: Module 01
grand_parent: Templates
nav_order: 2
---

# Topic Quiz

{% include mcq.html %}

<div id="CHANGE-THIS-ID"></div>

<script>
renderQuiz("CHANGE-THIS-ID", [
  {
    q: "Question text here?",
    options: ["Option A", "Option B", "Option C", "Option D"],
    answer: 0,
    explanation: "Explanation of why Option A is correct."
  },
  {
    q: "Second question?",
    options: ["Option A", "Option B", "Option C", "Option D"],
    answer: 2,
    explanation: "Explanation of why Option C is correct."
  }
]);
</script>

<!--
HOW TO USE:
1. Copy this file to your topic folder, e.g. docs/sql/quiz.md
2. Change front matter: title, parent, grand_parent (if 3rd level)
3. Change "CHANGE-THIS-ID" to something unique, e.g. "sql-quiz"
4. Fill in your questions
5. answer: is the index of the correct option (0 = first, 1 = second, etc.)
-->
