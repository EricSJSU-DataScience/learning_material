---
layout: default
title: Notes Template
parent: Module 02
grand_parent: Templates
nav_order: 1
---

# Topic Title

Brief one-line description of what this page covers.

---

## Concept

Explain the concept in plain English.

## Syntax

```python
example = "value"
```

## Examples

```python
x = 10
print(x)  # 10
```

## Key Points

- First important thing to remember
- Second important thing
- Edge case or common mistake

## Reference

| Term | Meaning |
|------|---------|
| variable | A named container for a value |
| function | A reusable block of code |
