---
layout: default
title: Module 02
parent: Templates
nav_order: 2
has_children: true
---

# Module 02: Basic Templates

| Template | Use for |
|----------|---------|
| [Notes](notes-template.md) | Reference notes and summaries |
| [Quiz](quiz-template.md) | Multiple choice questions |
| [Flashcards](flashcard-template.md) | Flip-card review |
