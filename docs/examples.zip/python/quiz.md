---
layout: default
title: Quiz
parent: Python
nav_order: 99
---

# Python Quiz

{% include mcq.html %}

<div id="python-quiz"></div>

<script>
renderQuiz("python-quiz", [
  {
    q: "What does <code>print()</code> do?",
    options: ["Displays output to the screen", "Reads user input", "Creates a variable", "Imports a module"],
    answer: 0,
    explanation: "print() displays text or values to the screen."
  },
  {
    q: "Which of these is a valid variable name in Python?",
    options: ["2score", "my_score", "my-score", "my score"],
    answer: 1,
    explanation: "Variable names can't start with a number, contain hyphens, or have spaces."
  },
  {
    q: "What is the output of: <code>print(type(3.14))</code>?",
    options: ["<class 'int'>", "<class 'str'>", "<class 'float'>", "<class 'number'>"],
    answer: 2,
    explanation: "3.14 has a decimal point, so it's a float."
  },
  {
    q: "What does <code>len(\"hello\")</code> return?",
    options: ["4", "5", "6", "hello"],
    answer: 1,
    explanation: "len() counts the number of characters. 'hello' has 5 characters."
  },
  {
    q: "Which keyword defines a function in Python?",
    options: ["function", "define", "def", "func"],
    answer: 2,
    explanation: "Python uses 'def' to define a function."
  },
  {
    q: "What is the output of: <code>print(\"3\" + \"4\")</code>?",
    options: ["7", "34", "3 4", "Error"],
    answer: 1,
    explanation: "Both are strings, so + concatenates them into '34'."
  },
  {
    q: "Which loop runs as long as a condition is True?",
    options: ["for loop", "while loop", "do loop", "repeat loop"],
    answer: 1,
    explanation: "A while loop keeps running as long as its condition is True."
  },
  {
    q: "What does <code>range(3)</code> produce?",
    options: ["[1, 2, 3]", "[0, 1, 2, 3]", "[0, 1, 2]", "[1, 2]"],
    answer: 2,
    explanation: "range(3) generates 0, 1, 2 — it starts at 0 and stops before 3."
  }
]);
</script>
