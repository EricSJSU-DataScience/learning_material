---
layout: default
title: Flashcards
parent: Python
nav_order: 98
---

# Python Flashcards

Click a card to reveal the answer. Use Shuffle to randomize.

{% include flashcard.html %}

<div id="python-cards"></div>

<script>
renderCards("python-cards", [
  { front: "What is a variable?", back: "A named container that stores a value.<br><code>x = 10</code>" },
  { front: "What data type is <code>3.14</code>?", back: "<code>float</code> — any number with a decimal point." },
  { front: "How do you define a function in Python?", back: "Use the <code>def</code> keyword:<br><code>def my_func():</code>" },
  { front: "What does <code>len()</code> do?", back: "Returns the number of items in a sequence.<br><code>len('hello') → 5</code>" },
  { front: "What is the difference between <code>=</code> and <code>==</code>?", back: "<code>=</code> assigns a value.<br><code>==</code> compares two values." },
  { front: "What does <code>range(5)</code> produce?", back: "The sequence <code>0, 1, 2, 3, 4</code>.<br>Starts at 0, stops before 5." },
  { front: "How do you add an item to a list?", back: "<code>my_list.append(item)</code>" },
  { front: "What is a <code>dict</code>?", back: "A collection of key-value pairs.<br><code>{'name': 'Alice', 'age': 30}</code>" }
]);
</script>
