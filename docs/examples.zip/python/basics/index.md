---
layout: default
title: Basics
parent: Python
nav_order: 1
has_children: true
---

# Python Basics

Foundational Python concepts.

- [Variables](variables.md)
- [Data Types](data-types.md)
