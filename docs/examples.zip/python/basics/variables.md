---
layout: default
title: Variables
parent: Basics
grand_parent: Python
nav_order: 1
---

# Variables

```python
x = 10
name = "Alice"
is_active = True
```
