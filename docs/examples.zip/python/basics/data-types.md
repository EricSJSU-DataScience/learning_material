---
layout: default
title: Data Types
parent: Basics
grand_parent: Python
nav_order: 2
---

# Data Types

| Type | Example |
|------|---------|
| int | `42` |
| float | `3.14` |
| str | `"hello"` |
| list | `[1, 2, 3]` |
| dict | `{"key": "value"}` |
